<?php
/**
 * The Joomap component administrator toolbar
 * @author Daniel Grothe
 * @see admin.joomap.php
 * @version $Id: toolbar.joomap.html.php 12 2008-08-17 20:51:27Z koders.de $
 */
	 
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

?>