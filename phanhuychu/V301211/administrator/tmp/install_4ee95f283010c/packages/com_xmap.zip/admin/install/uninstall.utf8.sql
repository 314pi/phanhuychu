drop table `#__xmap_items`;
drop table `#__xmap_sitemap`;