DELETE FROM `#__components` WHERE `link` LIKE 'option=com_frontenduserarticlelist' OR `option` LIKE 'com_frontenduserarticlelist';
