///Joomla SWmenuFree Component///
********* Copyright ***********

Copyright (C) 2005 Sean White : http://www.swmenupro.com/
All rights reserved

Name                  : swMenuFree
Description           : Joomla 1.5.x DHTML Component and Module
Component File Name   : com_swmenufree6.0.zip
Developer             : Sean White
Date                  : SEP. 02, 20108 
version               : 6.0




 

************* Install *************
Component Installation
----------------------
In Administrator Menu, go to Components, Install/Uninstall...
Go to the section Upload new component, browse and select the com_swmenufree6.0.zip file...
Press the Upload File button.  The module will install automatically when the component installs.



