<?php
// No direct access
defined( '_JEXEC' ) or die();

require_once dirname( __FILE__ ).'/nonumberelements/nonumberelements.php';